let resumeFormData = {
  name: "",
  email: "",
  phone: "",
  address: "",
  linkedin: "",
  Portifolio: "",
  githubURL: "",
  education: "",
  experience: "",
  skills: "",
  certificates: "",
  languages: "",
  references: "",
};
module.exports = resumeFormData;
